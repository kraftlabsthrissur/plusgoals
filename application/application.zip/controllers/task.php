<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * @author Ajith Vp <ajith@kraftlabs.com>
 * @copyright Copyright (c) 2015, Ajith Vp <ajith@kraftlabs.com>
 * @date 06-Mar-2015
 */

/**
 * @property task_model $task_model Description
 * 
 */
class Task extends Secure_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('task_model');
    }

    public function add() {
        $edit_mode = FALSE;
        $form_data = $this->input->post();
        if ($form_data !== FALSE) {
            $data = $this->save();
            if ($data['status'] === 'success') {
                header('Content-Type: application/json');
                echo json_encode($data);
            } else {
                $this->load->view('crm/form_task', $data);
            }
        } else {
            $data['edit_mode'] = $edit_mode;
            $this->load->view('crm/form_task', $data);
        }
    }

    public function edit($id) {
        $edit_mode = TRUE;
        $form_data = $this->input->post();
        if ($form_data !== FALSE) {
            $data = $this->save();
            if ($data['status'] === 'success') {
                header('Content-Type: application/json');
                echo json_encode($data);
            } else {
                $this->load->view('crm/form_task', $data);
            }
        } else {
            $data['edit_mode'] = $edit_mode;
            $form_data = $this->task_model->simple_get('tasks', array('*'), array('task_id' => $id));
            $data['form_data'] = $form_data[0];
            $this->load->view('crm/form_task', $data);
        }
    }

    public function list_view() {
        $user_data = $this->session->userdata('userdata');
        $where = "1 = 1 and t.is_active=1" ;
        if($user_data['umId']!=1){
            
        $data['subordinate_users']=$this->privilegemodel->get_subordinate_users($user_data['umId']);
        $subordinate_users=$data['subordinate_users']['user_id'];
        
        if($subordinate_users==null){
            $subordinate_users =$user_data['umId']; 
           }else{
             $subordinate_users =$user_data['umId'].','.$subordinate_users;  
           }
          $where="t.created_by in (".$subordinate_users.") and t.is_active=1"; 
        }
        $data = array();
        $data['table_data'] = $this->task_model->get_tasks($where);
        //print_r($data);
       //echo $this->db->last_query(); die();
        $this->load->view('crm/list_task', $data);
    }

    public function delete($id) {
        $form_data['is_active'] = 0;
        $result = $this->task_model->edit('tasks', $form_data, array('task_id' => $id));
        if ($result) {
            $data['status'] = 'success';
            $data['message'] = 'Deleted successfully';
            $data['hash'] = 'task/list_view';
        } else {
            $data['status'] = 'failure';
            $data['form_data'] = $form_data;
        }
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function is_valid_form($mode) {
        $form_data = $this->input->post();

//        $this->form_validation->set_rules('method_name', 'Method Name', 'required|max_length[100]');
//        $this->form_validation->set_rules('file_name', 'File Name', 'required|max_length[100]');
//        $this->form_validation->set_rules('class_name', 'Class Name', 'required|max_length[100]');
//        $this->form_validation->set_rules('description', 'Description', 'max_length[500]');

        return 1; //$this->form_validation->run();
    }

    private function save() {
        $edit_mode = FALSE;
        $form_data = $this->input->post();

        if (isset($form_data['task_id']) && $form_data['task_id'] !== '') { // edit
            $edit_mode = TRUE;
        }
        if (!$this->is_valid_form($edit_mode)) {
            $data['edit_mode'] = $edit_mode;
            $data['error'] = $this->form_validation->error_array();
            $data['form_data'] = $form_data;
            $data['status'] = 'failure';
        } else {
            if ($edit_mode) {
                $id = $form_data['task_id'];
                unset($form_data['task_id']);
                $this->task_model->log_activity('tasks', array('task_id' => $id), $form_data);
                $result = $this->task_model->edit('tasks', $form_data, array('task_id' => $id));
            } else {
                $userdata = $this->session->userdata('userdata');
                $form_data['created_by'] = $userdata['umId'];
                $form_data['is_active'] = 1;
                $form_data['created_date']=date('Y-m-d H:m:s');
                $result = $this->task_model->insert('tasks', $form_data);
            }
            if ($result) {
                $data['status'] = 'success';
                $data['message'] = 'Saved successfully';
                $data['hash'] = 'task/list_view';
            } else {
                $data['status'] = 'failure';
                $data['edit_mode'] = $edit_mode;
                $data['error'] = array('form_error' => 'Data not Saved');
                $data['form_data'] = $form_data;
            }
        }
        return $data;
    }
    public function select_user(){
        $data['task_id'] = $_POST['id'];
        $userWhere = "1=1";//and umStoreId is null
        $user_data = $this->session->userdata('userdata');
        if($user_data['umId']!=1){
            
        $data['subordinate_users']=$this->privilegemodel->get_subordinate_users($user_data['umId']);
        $subordinate_users=$data['subordinate_users']['user_id'];
        
        if($subordinate_users==null){
            $subordinate_users =$user_data['umId']; 
           }else{
             $subordinate_users =$user_data['umId'].','.$subordinate_users;  
           }
          $userWhere="umid in (".$subordinate_users.") "; 
        }
        $users = $this->task_model->simple_get('usermaster', array('umId as id ,umUserName as name'), $userWhere);
        $data['users'] = generate_options($users);
        $this->load->view('crm/assign_tasks', $data);
    }
    public function assign_task(){
        $data['task_id'] = $_POST['task_id'];
        $userdata = $this->session->userdata('userdata');
        $_POST['user_id']=$userdata['umId'];
       $result = $this->task_model->insert('user_tasks', $_POST); 
       
       $this->list_view();
    }

}
