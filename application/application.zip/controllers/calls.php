<?php

/**
 * @author Ajith Vp <ajith@kraftlabs.com>
 * @copyright Copyright (c) 2015, Ajith Vp <ajith@kraftlabs.com>
 * @date 06-Feb-2015
 */

/**
 * @property privilegemodel $privilegemodel Description
 * 
 */
class Calls extends Secure_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('routemodel');
        $this->load->model('list_model');
        $this->load->model('privilegemodel');
        $this->load->model('expensemodel');
        $this->load->model('callmodel');
    }

    public function list_calls() {
        $user_data = $this->session->userdata('userdata');
        $where = "1 = 1";
        if ($user_data['umId'] != 1) {

            $data['subordinate_users'] = $this->privilegemodel->get_subordinate_users($user_data['umId']);
            $subordinate_users = $data['subordinate_users']['user_id'];

            if ($subordinate_users == null) {
                $subordinate_users = $user_data['umId'];
            } else {
                $subordinate_users = $user_data['umId'] . ',' . $subordinate_users;
            }
            $where = "c.user_id in (" . $subordinate_users . ")";
        }
        $data['table_data'] = $this->callmodel->get_calls($where);
        $data['new_customer'] = $this->callmodel->simple_get('new_customer_call',array('*'),$where);

        //echo $this->db->last_query();die();
        $this->load->view('calls/list_calls', $data);
    }

    public function add_calls($id = null) {
        if ($id == null) {
            $edit_mode = FALSE;
        } else {
            $edit_mode = TRUE;
            $call_id['id'] = $id;
            $sample_id['call_id'] = $id;
            $call = $this->callmodel->simple_get('calls', array('*'), $call_id);
            $sample = $this->callmodel->simple_get('call_details_sample', array('*'), $sample_id);
            $prescribs = $this->callmodel->simple_get('call_details_prescribs', array('*'), $sample_id);
            $data['call'] = $call;

            $data['sample'] = $sample;
            $data['prescribs'] = $prescribs;
        }

        $form_data = $this->input->post();

        $user_data = $this->session->userdata('userdata');
        $customers = $this->callmodel->simple_get('storemaster', array('smid as id', 'smStoreName as name'));

        if ($user_data['umId'] == 1) {
            $where = "1=1";
            $routes = $this->routemodel->simple_get('routes', array('route_id as id', 'route_name as name'), $where);
        } else {
            $data['subordinate_users'] = $this->privilegemodel->get_subordinate_users($user_data['umId']);
            $subordinate_users = $data['subordinate_users']['user_id'];

            if ($subordinate_users == null) {
                $subordinate_users = $user_data['umId'];
            } else {
                $subordinate_users = $user_data['umId'] . ',' . $subordinate_users;
            }
            $where = "created_by in (" . $subordinate_users . ")";
            $routes = $this->routemodel->simple_get('routes', array('route_id as id', 'route_name as name'), $where);
        }
        if ($form_data !== FALSE) {
            $form_data['user_id'] = $user_data['umId'];
            $form_data['edit_mode'] = $edit_mode;
            // print_r($form_data);
            $data = $this->save_call($form_data);
            if ($data['status'] === 'success') {
                header('Content-Type: application/json');
                echo json_encode($data);
            } else {
                $data['routes'] = generate_options($routes, 0, 0, $form_data['route_id']);
                $data['customers'] = generate_options($customers, 0, 0, $form_data['route_id']);
                $this->load->view('calls/form_calls', $data);
            }
        } else {
            if ($edit_mode == TRUE) {
                $data['routes'] = generate_options($routes, 0, 0, $data['call'][0]['route_id']);
                $data['customers'] = generate_options($this->callmodel->select_customers($data['call'][0]['route_id']), 0, 0, $data['call'][0]['customer_id']);
            } else {
                $data['routes'] = generate_options($routes);
                $data['customers'] = generate_options($customers);
            }

            $data['user_data'] = $user_data;
            $data['edit_mode'] = $edit_mode;

            $this->load->view('calls/form_calls', $data);
        }
    }

    public function view_calls() {

        $calls_id['call_id'] = $_POST['id'];
        $call_id['id'] = $_POST['id'];
        $user_data = $this->session->userdata('userdata');
        $id['user_id'] = $user_data['umId'];
        $data['role'] = $this->callmodel->simple_get('roles', array('role_id', 'role_name'), 'role_id= ' . $user_data['role_id'] . '');
        $data['calls'] = $this->callmodel->get_calls_by_id($call_id);
        $data['prescribs'] = $this->callmodel->simple_get('call_details_prescribs', array('*'), $calls_id);
        $data['sample'] = $this->callmodel->simple_get('call_details_sample', array('*'), $calls_id);
        // print_r($data);die();
        $this->load->view('calls/view_calls', $data);
    }

    public function delete_call($id) {
        $this->callmodel->delete('calls', array('id' => $id));
        $this->callmodel->delete('call_details_sample', array('call_id' => $id));
        $this->callmodel->delete('call_details_prescribs', array('call_id' => $id));
        $user_data = $this->session->userdata('userdata');
        $this->list_calls();
    }

    public function customer_type() {
        $customer_id['smid'] = $_POST['id'];
        $result = $this->callmodel->simple_get('storemaster', array('customer_group'), $customer_id);
        print_r($result[0]['customer_group']);
    }

    public function save_call($form_data) {
        $user_data = $this->session->userdata('userdata');
        if ($form_data['edit_mode'] == 1) {


            $calls['route_id'] = $form_data['route_id'];
            $calls['user_id'] = $user_data['umId'];
            $calls['customer_id'] = $form_data['customer_id'];
            // $calls['date']=$form_data['date'];
            $calls['promotional_product'] = $form_data['promotional_product'];
            $calls['order_booked'] = $form_data['order_booked'];
            $calls['complaints'] = $form_data['complaints'];
            $calls['information_conveyed'] = $form_data['information_conveyed'];
            $calls['stock_availability'] = $form_data['stock_availability'];
            $calls['collection'] = $form_data['collection'];
            $calls['created_date'] = date('Y-m-d H:m:s');
            $calls_id['id'] = $form_data['id'];


            if (isset($form_data['status'])) {
                $calls['status'] = "visited";
                $calls['date'] = $form_data['date'];
            } else {
                $calls['status'] = "Not_visited";
                $calls['date'] = 00 - 00 - 00;
            }

            $result = $this->callmodel->update('calls', $calls, $calls_id);

            $call_id['call_id'] = $form_data['id'];
        } else {
            $calls['route_id'] = $form_data['route_id'];
            $calls['user_id'] = $user_data['umId'];
            $calls['customer_id'] = $form_data['customer_id'];
            //$calls['date']=$form_data['date'];
            $calls['promotional_product'] = $form_data['promotional_product'];
            $calls['order_booked'] = $form_data['order_booked'];
            $calls['complaints'] = $form_data['complaints'];
            $calls['information_conveyed'] = $form_data['information_conveyed'];
            $calls['stock_availability'] = $form_data['stock_availability'];
            $calls['collection'] = $form_data['collection'];
            $calls['created_date'] = date('Y-m-d H:m:s');

            if (isset($form_data['status'])) {
                $calls['status'] = "visited";
                $calls['date'] = $form_data['date'];
            } else {
                $calls['status'] = "Not_visited";
                $calls['date'] = 00 - 00 - 00;
            }
            $result = $this->callmodel->insert('calls', $calls);
            $call_id['call_id'] = $this->db->insert_id();
        }

        $this->callmodel->delete('call_details_prescribs', $call_id);
        $this->callmodel->delete('call_details_sample', $call_id);

        $prescribing['call_id'] = $call_id['call_id'];

        foreach ($form_data['product_name'] as $value) {
            $prescribing['prescribing_product'] = $value;

            $this->callmodel->insert('call_details_prescribs', $prescribing);
        }
        $sample['call_id'] = $call_id['call_id'];

        foreach ($form_data['sample_name'] as $row) {
            $sample['sample'] = $row;

            $this->callmodel->insert('call_details_sample', $sample);
        }

        if ($result) {
            $data['status'] = 'success';
            $data['message'] = 'Saved successfully';
            $data['hash'] = 'calls/list_calls';
        } else {
            $data['status'] = 'failure';
            $data['edit_mode'] = True;
            $data['error'] = array('form_error' => 'Data not Saved');
            $data['form_data'] = $form_data;
        }

        return $data;
    }

    public function select_customer() {
        $id = $this->callmodel->select_customers($_POST['id']);
        $customers = generate_options($id);
        echo $customers;
    }

    public function add_new_customer_calls($id = null) {
        if ($id == null) {
            $edit_mode = FALSE;
        } else {
            $edit_mode = TRUE;
            $new_call_id['id']=$id;
            $data['new_customer']=$this->callmodel->simple_get('new_customer_call',array('*'),$new_call_id);
        }
        $form_data = $this->input->post();

        $user_data = $this->session->userdata('userdata');
        if ($form_data != FALSE) {
            $form_data['user_id'] = $user_data['umId'];
            $form_data['edit_mode'] = $edit_mode;
            $data = $this->save_new_customer_calls($form_data);
            
            if ($data['status'] === 'success') {
                header('Content-Type: application/json');
                echo json_encode($data);
            } else {

                $this->load->view('calls/add_new_customer_form', $data);
            }
        }else{

        $data['user_id'] = $user_data['umId'];
        $data['edit_mode'] = $edit_mode;
        //print_r($data);die();
        $this->load->view('calls/add_new_customer_form', $data);
        }
    }

    public function save_new_customer_calls($data) {
        
        if ($data['edit_mode'] == 1) {
            $call_id['id']=$data['id'];
            $data['modified_date']=date('Y-m-d H:i:s');
            unset($data['edit_mode']);
            $result = $this->callmodel->update('new_customer_call', $data,$call_id);
           
        } else {
            unset($data['edit_mode']);
            unset($data['id']);
            $data['creation_date'] = date('Y-m-d');
            $result = $this->callmodel->insert('new_customer_call', $data);
           }
            if ($result) {
                $data['status'] = 'success';
                $data['message'] = 'Saved successfully';
                $data['hash'] = 'calls/list_calls';
            } else {
                $data['status'] = 'failure';
                $data['edit_mode'] = True;
                $data['error'] = array('form_error' => 'Data not Saved');
                $data['form_data'] = $form_data;
            }
            //print_r($data);die();
            return $data;
        
    }
     public function delete_new_customer_calls($id) {
        $this->callmodel->delete('new_customer_call', array('id' => $id));
        $this->list_calls();
     }

}
