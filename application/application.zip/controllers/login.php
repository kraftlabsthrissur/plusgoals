<?php

class Login extends Secure_Controller {

    public function __construct() {
        parent::__construct();
    }

    function index() {
        $message['status'] = '';
        if ($this->input->post('username') != null && $this->input->post('password') != null) {
            $this->load->model('connection');
            $data = $this->connection->getuser($this->input->post('username'), $this->input->post('password'));
            foreach ($data->result() as $row) {
                if ($row->cnt > 0) {
                    $datafield = $this->connection->getuserdet($this->input->post('username'), $this->input->post('password'));
                    foreach ($datafield->result() as $rows) {
                        $umId = $rows->umId;
                        $umUserName = $rows->umUserName;
                        $umFirstName = $rows->umFirstName;
                        $umLastName = $rows->umLastName;
                        $umEmail = $rows->umEmail;
                        $umStoreId = $rows->umStoreId;
                        $umIsHOUser = $rows->umIsHOUser;
                        $umIsSalesRep = $rows->umIsSalesRep;
                        $umIsManager = $rows->umIsManager;
                        $umIsActive = $rows->umIsActive;
                        $umCreationDate = $rows->umCreationDate;
                        $umRoleId = $rows->role_id;
                    }

                    $login = array(
                        'umId' => $umId,
                        'umUserName' => $umUserName,
                        'umFirstName' => $umFirstName,
                        'umLastName' => $umLastName,
                        'umEmail' => $umEmail,
                        'umStoreId' => $umStoreId,
                        'umIsHOUser' => $umIsHOUser,
                        'umIsSalesRep' => $umIsSalesRep,
                        'umIsManager' => $umIsManager,
                        'umIsActive' => $umIsActive,
                        'umCreationDate' => $umCreationDate,
                        'role_id' => $umRoleId
                    );
                    $this->session->set_userdata('userdata', $login);
                    $this->session->set_userdata('LoggedIn', true);

                    $formDetails = array();
                    $previlege = $this->session->userdata('previlege');
                    $datas = $this->connection->getSecurityUserAccess($login['umId']);
                    if ($datas->num_rows() > 0) {
                        foreach ($datas->result() as $res) {
                            if ($res->level == 2) {
                                $formDetails['formName'] = $res->suaFormName;
                                $previlege['formDetails'] = $res->suaFormName;
                                array_push($previlege, $res->suaFormName);
                            }
                            $this->session->set_userdata('previlege', $previlege);
                        }
                    }$previlege = $this->session->userdata('previlege');

                    $message['status'] = 'Login Successfully!';
                    redirect('', 'refresh');
                } else {
                    $message['status'] = 'Invalid username or password..!';
                    $this->load->view('login_view', $message);
                }
            }
        } else {
            $login = array(
                "LoggedIn" => ''
            );
            $data['username'] = 'sample';
            $this->session->sess_destroy();
            $this->load->view('login_view', $data);
        }
    }

    function logout() {
        $data['username'] = 'sample';
        $this->session->sess_destroy();
        $this->load->view('login_view', $data);
    }

}
