<?php
if(! defined('BASEPATH'))
	exit('No direct script access allowed');

/**
 *
 * @author Ajith Vp <ajith@kraftlabs.com>
 * @copyright Copyright (c) 2015, Ajith Vp <ajith@kraftlabs.com>
 *            @date 06-Feb-2015
 *           
 */
class Xml_Model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

}