<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @author ajith
 * @date 9 Mar, 2015
 */
class Deal_Model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

}
