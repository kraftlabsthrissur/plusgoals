<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @author ajith
 * @date 9 Mar, 2015
 */
class Task_Model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

//    public function get_tasks($condition) {
//        $this->db->select('*');
//        $this->db->from('tasks t');
//        $this->db->join('usermaster u1', 'u1.umId = t.created_by');
//        $this->db->join('usermaster u2', 'u2.umId = t.assigned_to','left');
//        $this->db->where($condition);
//        $query = $this->db->get();
//        if ($query->num_rows() > 0) {
//            $result = $query->result_array();
//            return $result;
//        }
//        return FALSE;
//    }
    public function  get_tasks($condition){
        $this->db->select('*');
        $this->db->from('tasks t');
        
        
        $this->db->where($condition,'',false);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        }
        return FALSE;
    }

}
