<?php
/**
 * @author ajith
 * @date 6 Feb, 2015
 */
?>


<section class="content-header">
    <h1>
       <?php echo $edit_mode ? "Edit" : "Add"; ?> Route
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo base_url(); ?>#listcontrol/show_routes"><i class="fa fa-laptop"></i> Route</a></li>
        <li class="active">Add Route</li>
    </ol>
</section>

<section id="content" class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <div class="col-xs-8">
                        <h3 class="box-title"><?php echo $edit_mode ? "Edit" : "Add"; ?> Route</h3>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">

                    <form  method="post" class="ajax-submit draw_routes" action="routes/<?php echo $edit_mode ? "edit_routes/" . $routes[0]['route_id'] : "add_routes"; ?>">
                        <div class="row">
                            <div class="col-xs-6">
                                <div class="row">
                                    <div class="col-xs-3">
                                        Route Name
                                    </div>
                                    <div class="col-xs-7">
                                        <input type="text"  class="required form-control" name="route_name" value="<?php echo @$routes[0]['route_name']; ?>" />
                                      <?php echo @$error['route_name']; ?>
                                    </div>

                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-3">
                                        HeadQuarters
                                    </div>
                                    <div class="col-xs-7">
                                        <select name="amId" class="form-control">
                                        <?php echo $headquarters; ?>
                                        </select>
                                       <?php echo @$error['amId']; ?>
                                    </div>

                                </div>
                                <br/>

                                <div class="row">
                                    <div class="col-xs-3">
                                        Starting Location
                                    </div>
                                    <div class="col-xs-7">
                                        <input type="text"  class="required form-control" id="selected_location" name="starting_location" value="<?php echo @$routes[0]['starting_location']; ?>" />
                                          <?php echo @$error['starting_location']; ?>
                                    </div>

                                </div>
                                <br/>

                                <div class="row">
                                    <div class="col-xs-3">
                                        Customers Name
                                    </div>
                                    <div class="col-xs-7">
<!--                                        <input type="text"  class="required form-control" name="customers_name" value="<?php echo @$form_data['customers_name']; ?>" />-->
                                        <select name="smId" class="form-control">
                                        <?php echo $customers; ?>
                                        </select>  
                                        <?php echo @$error['smId']; ?>
                                    </div>
                                    <div class="col-xs-2">

                                        <input type="button" class="btn btn-primary add_route_place" id="add_route" value="Add">

                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-3"></div>
                                        <?php if ($edit_mode = "Edit" && isset($routes)) { ?>
                                        <div class="col-xs-7 route_places" id="route" >
                                        <?php foreach ($routes as $key => $value) { ?>
                                                   <li class="col-xs-12" style="text-align:left;color:#00c0ef;" >
                                                    <input type="hidden" class="selected_place"name="customer_id[]" value="<?php echo $value['customer_id'] ?>">
                                                    <input type="hidden" class="selected_place"name="place[]" value="<?php echo $value['place'] ?>">
                                                    <input type="hidden" class="place_address"name="place_address[]" value="<?php echo $value['address'] ?>">
                                                    <input type="hidden" class="place_lat"name="place_lat[]" value="<?php echo $value['latitude'] ?>">
                                                    <input type="hidden" class="place_lng"name="place_lng[]" value="<?php echo $value['longitude'] ?>"><?php echo $value['place'] ?>
                                                    <span a href="#" class="closeList pull-right">X</span></li> 
                                                   
                                        <?php } ?>
                                                   </div>
                                        <?php } else { ?>
                                        <div class="col-xs-7 route_places hidden" id="route" >

                                        </div>
                                         <?php } ?>
                                </div>
                                <br/> 

                                <div class="row">
                                    <div class="col-xs-3"></div>
                                    <div class="col-xs-7" id="directions-panel"></div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-3">
                                    </div>
                                    <div class="col-xs-7">
                                        <input type="submit" class="btn btn-primary" id="route_save"  Value="Save"/>
                                        <input type="reset" class="btn btn-warning"  Value="Reset"/>
                                        <input type="hidden"  name="route_id" Value="<?php echo @$routes[0]['route_id']; ?>"/>
                                    </div>
                                </div>
                                <br/>
                            </div>
                            <div class="col-xs-6" style="height: 80%">
                                <div id="map" style="width: 100%; height:400px"></div>
                            </div>
                        </div>                     
                    </form>
                </div><!--tablecontent-->
            </div><!--subcontent-->
        </div>
    </div>
</section>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDhKZXS8GzDWzBS9zts0rEStbydHeyvFw0&libraries=places&callback=initMap"></script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcROIeZfc62e-8CFHZygizUNCLMKNXooY&libraries=places&callback=initMap"></script>-->
<!--        <script src="<?php echo base_url(); ?>assets/js/jquery.geocomplete.js"></script>-->


<script type="text/javascript">

    $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd.mm.yy'
    });
    


    



</script>

