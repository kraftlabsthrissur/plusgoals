<section class="content-header">
    <h1>
        <?php echo $edit_mode ? "Edit" : "Add"; ?> Call
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo base_url(); ?>#listcontrol/show_call"><i class="fa fa-laptop"></i> Call</a></li>
        <li class="active">Add call</li>
    </ol>
</section>

<!-- Main content -->
<section id="content" class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-info">
                <div class="box-header">
                    <div class="col-xs-8">
                        <h3 class="box-title"><?php echo $edit_mode ? "Edit" : "Add"; ?> Call</h3>
                    </div>

                </div><!-- /.box-header -->
                <div class="box-body ">

                    <form  method="post" class="ajax-submit" action="calls/<?php echo $edit_mode ? "add_calls/" . $call[0]['id'] : "add_calls"; ?>">

                        <div class="calls">
                            <div class="row">
                                <div class="col-xs-4">
                                    <label> Select Route </label>
                                    <select name="route_id" class="form-control route">
                                        <option value="">Select Route</option>
                                        <?php echo $routes; ?>
                                    </select>
                                    <?php echo isset($error['route_id']); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4" >
                                    <label> Select Customer </label>
                                    <select id="select_customer" name="customer_id" class="form-control customer">
                                        <option value="" >Select Customer</option>
                                        <?php echo $customers; ?>
                                    </select>
                                    <?php echo isset($error['customer_id']); ?>
                                </div>
                                <div class="col-xs-2 customer_type hidden" style="height:60px !important;">
                                </div> 
                            </div>
                           <div class="row">
                                <div class="col-xs-4">
                                    <label> Visited Date </label>
                                    <input type="text" id="visited_date" name="date" class="form-control date datepicker" value="<?php
                                    if (isset($call[0]['date']) && $call[0]['status']=="visited") {
                                        echo $call[0]['date'];
                                    } else {
                                        echo Date('Y-m-d');
                                    }
                                    ?>">
                                </div>
                            </div>
                            <div class="row">    
                                <div class="col-xs-4">
                                    <label>Prescribing Product</label>
                                    <input type="text" name="prescribing_product"  class="form-control prescribing_product" value="">
                                </div> 
                                
                                <div class="col-xs-2"style="height: 51px!important;">
                                    <input type="button" class="btn btn-primary add_prescribing" value="ADD" style="position: absolute;bottom:0px;">
                                </div>    
                            </div>
                            <div class="row"> 
                                <?php if (isset($prescribs)) { ?>
                                    <div class="col-xs-4 prescribed_products">
                                        <?php foreach ($prescribs as$key=> $value){ ?>
                                            <li class="col-xs-12 custome-li" style="text-align:left;color:#00c0ef;" >
                                                <input type="hidden" class="product_name"name="product_name[]" value="<?php echo $value['prescribing_product']; ?>">
                                                <?php echo $value['prescribing_product']; ?>
                                                <span a href="#" class="closeList_pdct pull-right">X</span></li>
                                        <?php } ?>
                                    </div> 
                                <?php } else { ?>
                                    <div class="col-xs-4 prescribed_products hidden">

                                    </div> 
                                <?php } ?>
                            </div> 
                            <div class="row">    
                                <div class="col-xs-4">
                                    <label>Sample Product Given</label>
                                    <input type="text" name="sample_given"  class="form-control sample_given" value="">
                                </div> 
                                <div class="col-xs-2"style="height: 51px!important;">
                                    <input type="button" class="btn btn-primary add_sample_product" value="ADD" style="position: absolute;bottom:0px;">
                                </div>    
                            </div>
                             <div class="row"> 
                                <?php if(isset($sample)) { ?> 
                                <div class="col-xs-4 sample_products ">
                                     <?php foreach ($sample as$key=> $value){ ?>
                                            <li class="col-xs-12 custome-li" style="text-align:left;color:#00c0ef;" >
                                                <input type="hidden" class="sample_name"name="sample_name[]" value="<?php echo $value['sample']; ?>">
                                                <?php echo $value['sample']; ?>
                                                <span a href="#" class="closeList_sampl pull-right">X</span></li>
                                        <?php } ?> 
                                </div> 
                                 <?php } else { ?>
                                    <div class="col-xs-4 sample_products hidden">

                                    </div> 
                                <?php } ?>
                            </div> 
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>promotional Product</label>
                                    <input type="text" name="promotional_product" class="form-control promotional_product" value="<?php echo isset($call[0]['promotional_product']) ?$call[0]['promotional_product'] :"";?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>Amount Of Order Booked</label>
                                    <input type="text" name="order_booked" class="form-control order_booked" value="<?php echo isset($call[0]['order_booked']) ?$call[0]['order_booked'] :"";?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>Stock Availability</label>
                                   <input type="text" name="stock_availability" class="form-control stock_availability" value="<?php echo isset($call[0]['stock_availability']) ?$call[0]['stock_availability'] :"";?>">
                               </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>Complaints</label>
                                    <textarea type="text" name="complaints" class="form-control complaints" value=""><?php echo isset($call[0]['complaints']) ?$call[0]['complaints'] :"";?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>information Conveyed</label>
                                    <textarea type="text" name="information_conveyed" class="form-control information_conveyed" value=""><?php echo isset($call[0]['information_conveyed']) ?$call[0]['information_conveyed'] :"";?></textarea>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-xs-4" >
                                    <label>Collection</label>
                                    <input type="text" name="collection" class="form-control total" value="<?php
                                    if (isset($call[0]['collection'])) {
                                        echo $call[0]['collection'];
                                    } else {
                                        echo 0;
                                    }
                                    ?>">
                                </div>
                                
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-xs-4">
                                    <label>visited</label>  <input type="checkbox" name="status" value="" <?php if(isset($call[0]['status']) && $call[0]['status']=="visited") {?> checked <?php } ?> >  
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4" style="height:54px !important;">
                                    <?php if (isset($call[0]['id'])) { ?>
                                        <input type="hidden" name="id" value="<?php echo $call[0]['id']; ?>">
                                        <input type="submit" id="save_call" class="btn btn-primary" style="position: absolute;bottom:0px;" value="Save">
                                    <?php } else {
                                        ?>
                                        <input type="submit" id="add_call" class="btn btn-primary" style="position: absolute;bottom:0px;" value="submit">
                                    <?php } ?>

                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>  

</section>
<script>
    $("#visited_date").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'yy-mm-dd'
    });
</script>

