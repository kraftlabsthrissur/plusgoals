   
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title"><i class="fa fa-laptop"></i> Message</h4>
</div>
<br/>
<div class="row">
    <div class="col-xs-12">
        <div class="list box box-info">
       <div class="items box-body" id="message"> 
                <div class="row">
                <div class="col-xs-6" > 
                    <label>Message</label>
                    <textarea class="form-control message_head" name="meassage_head"></textarea>
                </div>
                <div class="col-xs-6">
                    <label>Message Content</label>
                    <textarea class="form-control message_content" name="meassage_content"></textarea>
                </div>     
            </div>
        </div>
        <div class="modal-footer clearfix">
            <button type="button" class="btn btn-danger" data-dismiss="modal" id="close" >
                <i class="fa fa-times"></i> Cancel
            </button>
            <button type="button" class="btn btn-primary pull-left" id="send_message" >
                <i class="fa fa-check"></i> Ok
            </button>
        </div>
    </div>
</div>
</div>
</div>